package com.example.cw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    Movie x = new Movie("Avengers", "Superman", 10.0, 13, "Superhero");
    Movie y = new Movie("Karate Kid", "Daniel", 9.0, 13, "Comedy");

    }
}